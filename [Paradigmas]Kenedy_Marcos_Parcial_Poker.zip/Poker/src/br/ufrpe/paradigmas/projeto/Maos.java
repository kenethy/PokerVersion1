package br.ufrpe.paradigmas.projeto;

public enum Maos {
	cartaAlta, par, doisPares, trinca, sequencia, flush, fullHouse, quadra, straightFlush, royalFlush
}